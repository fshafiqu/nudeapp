﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace insurapp_Core_MVC.Models
{
    public class Items
    {
        [Key]
        public int Id { get; set; }

        [Column(TypeName ="varchar(50)")]
        public string name { get; set; }

        [Column(TypeName = "varchar(50)")]
        [DisplayFormat(DataFormatString = "{0:c}", ApplyFormatInEditMode = true)]
        public double value { get; set; }

        [Column(TypeName = "varchar(50)")]
        public string category { get; set; }
    }
}
