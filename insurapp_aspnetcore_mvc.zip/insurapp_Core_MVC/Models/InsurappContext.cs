﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace insurapp_Core_MVC.Models
{
    public class InsurappContext : DbContext
    {
        public InsurappContext(DbContextOptions<InsurappContext> options) : base(options)
        {            
        }
        public DbSet<Items> Items { get; set; }

    }
}
